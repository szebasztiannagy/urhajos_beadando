﻿using _2024_urhajobead;
using System.Collections.Generic;
using System.Threading;
using System;
using System.Linq;

class Urbazis
{
    private char[,] palya;
    private bool[,] felfedezett;
    private int rows;
    private int columns;
    private Random random = new Random();

    private Dictionary<object, (int, int)> elemekPozicioi;

    public Urhajos Urhajos { get; private set; }
    public List<Robot> Robotok { get; private set; }
    public List<Kanna> UzemanyagKannak { get; private set; }
    public List<Csoki> MarsCsokik { get; private set; }
    public Kapu Kapu { get; private set; }
    public SzuperAlien SzuperAlien { get; private set; }

    public Urbazis(int meret)
    {
        rows = meret;
        columns = meret;
        palya = new char[rows, columns];
        felfedezett = new bool[rows, columns];
        elemekPozicioi = new Dictionary<object, (int, int)>();
        InicializalPalya();

        Robotok = new List<Robot>();
        UzemanyagKannak = new List<Kanna>();
        MarsCsokik = new List<Csoki>();

        ElhelyezzukAzElemeket();
    }

    private void InicializalPalya()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                if (i == 0 || i == rows - 1 || j == 0 || j == columns - 1)
                {
                    palya[i, j] = '#';  
                }
                else
                {
                    palya[i, j] = 'G';
                }
                felfedezett[i, j] = false; 
            }
        }
    }

    private void ElhelyezzukAzElemeket()
    {
        Urhajos = new Urhajos();
        HozzaadElemet(Urhajos, 'Ű');

        for (int i = 0; i < 4; i++)
        {
            Robot robot = new Robot();
            Robotok.Add(robot);
            HozzaadElemet(robot, 'R');
        }

        for (int i = 0; i < 3; i++)
        {
            Kanna uzemanyagKanna = new Kanna();
            UzemanyagKannak.Add(uzemanyagKanna);
            HozzaadElemet(uzemanyagKanna, 'U');
        }

        for (int i = 0; i < 4; i++)
        {
            Csoki marsCsoki = new Csoki();
            MarsCsokik.Add(marsCsoki);
            HozzaadElemet(marsCsoki, 'M');
        }

        Kapu = new Kapu();
        HozzaadElemet(Kapu, 'K');

        SzuperAlien = new SzuperAlien();
        HozzaadElemet(SzuperAlien, 'A');
    }

    private void HozzaadElemet(object elem, char jel)
    {
        (int x, int y) pozicio;

        if (jel == 'K')
        {
            do
            {
                int edge = random.Next(4);
                switch (edge)
                {
                    case 0:
                        pozicio = (0, random.Next(1, columns - 1));
                        break;
                    case 1:
                        pozicio = (rows - 1, random.Next(1, columns - 1));
                        break;
                    case 2:
                        pozicio = (random.Next(1, rows - 1), 0);
                        break;
                    case 3:
                        pozicio = (random.Next(1, rows - 1), columns - 1);
                        break;
                    default:
                        pozicio = (0, 0);
                        break;
                }
            } while (palya[pozicio.x, pozicio.y] != '#');
        }
        else
        {
            do
            {
                pozicio = (random.Next(1, rows - 1), random.Next(1, columns - 1));
            } while (palya[pozicio.x, pozicio.y] != 'G');
        }

        palya[pozicio.x, pozicio.y] = jel;
        elemekPozicioi[elem] = pozicio;
    }

    private (int, int) legkozelebbiKanna()
    {
        (int closestX, int closestY) = (-1, -1);
        var currentPos = elemekPozicioi[Urhajos];

        Queue<(int, int)> queue = new Queue<(int, int)>();
        HashSet<(int, int)> visited = new HashSet<(int, int)>();
        queue.Enqueue(currentPos);
        visited.Add(currentPos);

        while (queue.Count > 0)
        {
            (int x, int y) position = queue.Dequeue();

            foreach (var kannPos in UzemanyagKannak.Select(k => elemekPozicioi[k]))
            {
                if (position == kannPos)
                {
                    return (position.Item1, position.Item2);
                }
            }


            var directions = new (int, int)[]
            {
                    (1, 0), (-1, 0), (0, 1), (0, -1)
            };

            foreach (var direction in directions)
            {
                (int newX, int newY) = (position.Item1 + direction.Item1, position.Item2 + direction.Item2);

                if (IsValidMove(newX, newY) && !visited.Contains((newX, newY)))
                {
                    queue.Enqueue((newX, newY));
                    visited.Add((newX, newY));
                }
            }
        }

        return (-1, -1);
    }



    public void Szimulal()
    {
        while (true)
        {
            Console.Clear();
            MozgatUrhajos();
            FelfedezTeruletet();
            Megjelenit();
            Thread.Sleep(500);

            if (elemekPozicioi[Urhajos] == elemekPozicioi[Kapu])
            {
               
                break;
            }
        }
    }

    private void FelfedezTeruletet()
    {
        (int x, int y) urhajosPozicio = elemekPozicioi[Urhajos];

  
        for (int i = Math.Max(0, urhajosPozicio.x - 1); i <= Math.Min(rows - 1, urhajosPozicio.x + 1); i++)
        {
            for (int j = Math.Max(0, urhajosPozicio.y - 1); j <= Math.Min(columns - 1, urhajosPozicio.y + 1); j++)
            {
                felfedezett[i, j] = true;
            }
        }
    }

    private void MozgatUrhajos()
    {
        (int x, int y) currentPos = elemekPozicioi[Urhajos];

        if (UzemanyagKannak.Count > 0) 
        {
            (int targetX, int targetY) = legkozelebbiKanna();

            if (targetX == -1 && targetY == -1) return;

            (int newX, int newY) newPos = currentPos;

            if (targetX < currentPos.Item1) newPos.Item1--;
            else if (targetX > currentPos.Item1) newPos.Item1++;
            else if (targetY < currentPos.Item2) newPos.Item2--;
            else if (targetY > currentPos.Item2) newPos.Item2++;

            if (IsValidMove(newPos.Item1, newPos.Item2)) 
            {
                palya[currentPos.Item1, currentPos.Item2] = 'G'; 
                palya[newPos.Item1, newPos.Item2] = 'Ű';
                elemekPozicioi[Urhajos] = newPos; 

                FelfedezTeruletet(); 
                itemKereses(newPos); 
            }
        }
        else
        {
            lepesKapu(); 
        }
    }


    private void lepesKapu()
    {
        (int gateX, int gateY) = elemekPozicioi[Kapu];
        (int x, int y) currentPos = elemekPozicioi[Urhajos];

        (int newX, int newY) newPos = currentPos;

        if (gateX < currentPos.Item1) newPos.Item1--;
        else if (gateX > currentPos.Item1) newPos.Item1++;
        else if (gateY < currentPos.Item2) newPos.Item2--;
        else if (gateY > currentPos.Item2) newPos.Item2++;

        if (IsValidMove(newPos.Item1, newPos.Item2))  
        {
            palya[currentPos.Item1, currentPos.Item2] = 'G';  
            palya[newPos.Item1, newPos.Item2] = 'Ű'; 
            elemekPozicioi[Urhajos] = newPos;  

            FelfedezTeruletet(); 
            itemKereses(newPos);  
        }
    }


    private bool IsValidMove(int x, int y)
    {
        return x > 0 && x < rows - 1 && y > 0 && y < columns - 1 && palya[x, y] != '#';
    }

    private void itemKereses((int x, int y) position)
    {
        switch (palya[position.x, position.y])
        {
            case 'M':
              
                MarsCsokik.RemoveAll(marsCsoki => elemekPozicioi[marsCsoki] == position);
                break;
            case 'U':
                Console.WriteLine("Az űrhajós összegyűjtötte az összes üzemanyagkannát");
                var kannaToRemove = UzemanyagKannak.FirstOrDefault(kanna => elemekPozicioi[kanna] == position);
                if (kannaToRemove != null)
                {
                    UzemanyagKannak.Remove(kannaToRemove);
                }
                palya[position.x, position.y] = 'G'; 
                Urhajos.hp = Math.Min(Urhajos.hp + 10, 100);  
                break;
            case 'K':
                if (UzemanyagKannak.Count == 0)
                {
                    Console.WriteLine("AZ űrhajós elérte a kput és begyűjtötte az összes üzemanyag kannát!");
                    Environment.Exit(0);
                }
                break;
        }
    }


    public void Megjelenit()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                if (!felfedezett[i, j])
                {
                    Console.BackgroundColor = ConsoleColor.Black;  
                    Console.Write("  ");
                }
                else
                {
                    switch (palya[i, j])
                    {
                        case 'Ű':
                            Console.BackgroundColor = ConsoleColor.Cyan;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'R':
                            Console.BackgroundColor = ConsoleColor.Yellow;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'U':
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'M':
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'A':
                            Console.BackgroundColor = ConsoleColor.Magenta;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'K':
                            Console.BackgroundColor = ConsoleColor.Blue;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case '#':
                            Console.BackgroundColor = ConsoleColor.Gray;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                        case 'G':
                            Console.BackgroundColor = ConsoleColor.White;
                            Console.ForegroundColor = ConsoleColor.Black;
                            break;
                    }
                    Console.Write(palya[i, j] + " ");
                    Console.ResetColor();
                }
            }
            Console.WriteLine();
        }
    }
}
